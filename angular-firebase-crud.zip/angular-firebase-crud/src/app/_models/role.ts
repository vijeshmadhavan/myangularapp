export enum Role {
    Supervisor = 'Supervisor',
    Worker = 'Worker'
}