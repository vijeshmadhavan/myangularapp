# angular-11-firebase crud

Angular 11 - Firebase CRUD